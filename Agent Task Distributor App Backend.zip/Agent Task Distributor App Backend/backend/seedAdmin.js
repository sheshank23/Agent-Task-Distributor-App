const mongoose = require('mongoose');
const bcrypt = require('bcryptjs');
require('dotenv').config();

const User = require('./models/User');

const insertAdmin = async () => {
  try {
    await mongoose.connect(process.env.MONGO_URI, {
      useNewUrlParser: true,
      useUnifiedTopology: true,
    });

    await User.deleteMany({}); // Remove any existing users

    const hashedPassword = await bcrypt.hash('admin123', 10);

    const admin = new User({
      email: 'admin@example.com',
      password: hashedPassword,
    });

    await admin.save();
    console.log('✅ Admin user created with hashed password.');
    process.exit();
  } catch (error) {
    console.error('❌ Error inserting admin:', error);
    process.exit(1);
  }
};

insertAdmin();
