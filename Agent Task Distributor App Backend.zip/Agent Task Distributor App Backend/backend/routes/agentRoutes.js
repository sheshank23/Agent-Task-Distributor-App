const express = require('express');
const router = express.Router();
const Agent = require('../models/Agent');
const bcrypt = require('bcryptjs');

router.post('/', async (req, res) => {
  const { name, email, phone, password } = req.body;
  try {
    const hashedPassword = await bcrypt.hash(password, 10);
    const newAgent = new Agent({ name, email, phone, password: hashedPassword });
    await newAgent.save();
    res.status(201).json({ msg: 'Agent added successfully' });
  } catch (err) {
    res.status(500).json({ msg: err.message });
  }8
});

module.exports = router;
