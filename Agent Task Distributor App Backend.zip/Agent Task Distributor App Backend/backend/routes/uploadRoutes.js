const express = require('express');
const router = express.Router();
const multer = require('multer');
const csv = require('csv-parser');
const fs = require('fs');
const Task = require('../models/Task');
const Agent = require('../models/Agent');

const upload = multer({ dest: 'uploads/' });

router.post('/', upload.single('file'), async (req, res) => {
  console.log('🔄 CSV Upload Hit');
  console.log('📁 File Info:', req.file);

  try {
    if (!req.file) return res.status(400).json({ msg: 'No file uploaded' });

    const results = [];
    fs.createReadStream(req.file.path)
      .pipe(csv())
      .on('data', (data) => results.push(data))
      .on('end', async () => {
        const agents = await Agent.find();
        if (agents.length === 0) return res.status(400).json({ msg: 'No agents found' });

        const totalTasks = results.length;
const totalAgents = agents.length;
let agentIndex = 0;

console.log(`📦 Total Tasks: ${totalTasks}`);
console.log(`👥 Total Agents: ${totalAgents}`);

for (let i = 0; i < totalTasks; i++) {
  const taskData = results[i];
  const agent = agents[agentIndex];

  const task = new Task({
    agentId: agent._id,
    firstName: taskData.FirstName,
    phone: taskData.Phone,
    notes: taskData.Notes,
  });

  await task.save();
  console.log(`✅ Task ${i + 1} assigned to ${agent.name}`);

  agentIndex = (agentIndex + 1) % totalAgents; // round-robin
}


        fs.unlinkSync(req.file.path);
        console.log('✅ CSV Processed & Tasks Saved');
        res.json({ msg: 'CSV processed and tasks distributed' });
      });
  } catch (err) {
    console.error('❌ Upload Failed:', err.message);
    res.status(500).json({ msg: err.message });
  }
});


router.get('/tasks', async (req, res) => {
  try {
    const tasks = await Task.find().populate('agentId', 'name email');
    const grouped = {};

    tasks.forEach(task => {
      const agentName = task.agentId?.name || 'Unknown';
      if (!grouped[agentName]) grouped[agentName] = [];
      grouped[agentName].push({
        firstName: task.firstName,
        phone: task.phone,
        notes: task.notes
      });
    });

    res.json(grouped);
  } catch (err) {
    res.status(500).json({ msg: err.message });
  }
});

module.exports = router;
