const express = require('express');
const router = express.Router();
const User = require('../models/User');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');

router.post('/login', async (req, res) => {
  const { email, password } = req.body;

  // Log request details
  console.log(' Login Attempt:', { email, password });

  try {
    const user = await User.findOne({ email });
    console.log(' User Found:', user);

    if (!user) {
      console.log(' No user with that email');
      return res.status(400).json({ msg: 'Invalid credentials' });
    }

    const isMatch = await bcrypt.compare(password, user.password);
    console.log(' Password Match:', isMatch);

    if (!isMatch) {
      console.log(' Password mismatch');
      return res.status(400).json({ msg: 'Invalid credentials' });
    }

    const token = jwt.sign({ id: user._id }, process.env.JWT_SECRET, { expiresIn: '1h' });
    console.log(' JWT Token Generated:', token);

    res.json({ token });
  } catch (err) {
    console.error(' Server Error:', err.message);
    res.status(500).json({ msg: err.message });
  }
});

module.exports = router;
