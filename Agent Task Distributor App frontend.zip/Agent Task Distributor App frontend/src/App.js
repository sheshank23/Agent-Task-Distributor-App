import React from 'react';
import { Routes, Route } from 'react-router-dom';
import Login from './pages/Login';
import UploadCSV from './pages/UploadCSV';
import AddAgent from './pages/AddAgent';
import AgentTasks from './pages/AgentTasks';
import AdminDashboard from './pages/AdminDashboard';

function App() {
  return (
    <Routes>
      <Route path="/" element={<Login />} />
      <Route path="/upload" element={<UploadCSV />} />
      <Route path="/add-agent" element={<AddAgent />} />
      <Route path="/my-tasks" element={<AgentTasks />} />
      <Route path="/dashboard" element={<AdminDashboard />} />
    </Routes>
  );
}

export default App;