import React from 'react';
import { Link } from 'react-router-dom';

export default function AdminDashboard() {
  return (
    <div className="min-h-screen bg-[#d6d1e8] flex items-center justify-center px-4">
      <div className="bg-white rounded-[2rem] shadow-xl w-full max-w-4xl p-12">
        <h1 className="text-3xl font-semibold text-center text-gray-800 mb-10">Admin Dashboard</h1>
        
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-8">
          <Link
            to="/upload"
            className="bg-blue-500 hover:bg-blue-600 transition-all duration-300 text-white p-6 rounded-2xl text-center shadow-md text-lg font-medium"
          >
            📤 Upload Tasks
          </Link>

          <Link
            to="/add-agent"
            className="bg-green-500 hover:bg-green-600 transition-all duration-300 text-white p-6 rounded-2xl text-center shadow-md text-lg font-medium"
          >
            ➕ Add Agent
          </Link>

          <Link
            to="/my-tasks"
            className="bg-indigo-500 hover:bg-indigo-600 transition-all duration-300 text-white p-6 rounded-2xl text-center shadow-md text-lg font-medium"
          >
            📋 View Agent Tasks
          </Link>
        </div>
      </div>
    </div>
  );
}
