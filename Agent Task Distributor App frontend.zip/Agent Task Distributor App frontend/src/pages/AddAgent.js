import React, { useState } from 'react';
import axios from 'axios';
import { allCountries } from 'country-telephone-data';
import Select from 'react-select';

export default function AddAgent() {
  const [form, setForm] = useState({
    name: '',
    email: '',
    mobile: '',
    password: '',
  });
  const [countryCode, setCountryCode] = useState({ label: 'India (+91)', value: '+91' });
  const [message, setMessage] = useState('');
  const [isSuccess, setIsSuccess] = useState(false);

  const options = allCountries.map((country) => ({
    label: `${country.name} (+${country.dialCode})`,
    value: `+${country.dialCode}`,
  }));

  const handleChange = (e) => {
    setForm({ ...form, [e.target.name]: e.target.value });
    setMessage('');
  };

  const handleCountryChange = (selectedOption) => {
    setCountryCode(selectedOption);
    setMessage('');
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    const fullPhone = `${countryCode.value}${form.mobile}`;

    try {
      const token = localStorage.getItem('token');
      await axios.post(
        'http://localhost:5000/api/agents',
        { ...form, phone: fullPhone },
        {
          headers: { Authorization: `Bearer ${token}` },
        }
      );
      setMessage('✅ Agent added successfully!');
      setIsSuccess(true);
      setForm({ name: '', email: '', mobile: '', password: '' });
    } catch (err) {
      setMessage('❌ Failed to add agent.');
      setIsSuccess(false);
    }
  };

  return (
    <div className="min-h-screen bg-[#d6d1e8] flex items-center justify-center px-4">
      <form
        onSubmit={handleSubmit}
        className="bg-white p-10 rounded-[2rem] shadow-xl w-full max-w-md space-y-6"
      >
        <h2 className="text-2xl font-bold text-center text-gray-800">Add Agent</h2>

        <input
          type="text"
          name="name"
          placeholder="Full Name"
          className="w-full p-2 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-purple-400"
          value={form.name}
          onChange={handleChange}
        />

        <input
          type="email"
          name="email"
          placeholder="Email"
          className="w-full p-2 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-purple-400"
          value={form.email}
          onChange={handleChange}
        />

        <Select
          options={options}
          value={countryCode}
          onChange={handleCountryChange}
          placeholder="Select Country Code"
          className="text-sm"
        />

        <input
          type="text"
          name="mobile"
          placeholder="Mobile Number (without country code)"
          className="w-full p-2 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-purple-400"
          value={form.mobile}
          onChange={handleChange}
        />

        <input
          type="password"
          name="password"
          placeholder="Password"
          className="w-full p-2 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-purple-400"
          value={form.password}
          onChange={handleChange}
        />

        <button
          type="submit"
          className="w-full bg-blue-500 text-white py-2 rounded hover:bg-blue-600 transition-all"
        >
          ➕ Add Agent
        </button>

        {message && (
          <p
            className={`text-center text-sm font-medium transition-all ${
              isSuccess ? 'text-green-600' : 'text-red-600'
            }`}
          >
            {message}
          </p>
        )}
      </form>
    </div>
  );
}
