import React, { useEffect, useState } from 'react';
import axios from 'axios';

export default function AgentTasks() {
  const [taskGroups, setTaskGroups] = useState({});
  const [error, setError] = useState('');

  useEffect(() => {
    const fetchTasks = async () => {
      try {
        const res = await axios.get('http://localhost:5000/api/upload/tasks');
        setTaskGroups(res.data);
      } catch (err) {
        console.error('Failed to fetch tasks:', err);
        setError('Could not load tasks');
      }
    };

    fetchTasks();
  }, []);

  const allEmpty =
    Object.keys(taskGroups).length === 0 ||
    Object.values(taskGroups).every((tasks) => tasks.length === 0);

  return (
    <div className="min-h-screen bg-[#d6d1e8] px-6 py-10">
      <div className="max-w-4xl mx-auto bg-white rounded-[2rem] p-10 shadow-xl">
        <h2 className="text-3xl font-bold mb-6 text-center text-gray-800">📋 Agent Tasks</h2>

        {error && <p className="text-red-600 text-center">{error}</p>}

        {allEmpty ? (
          <p className="text-center text-gray-700">No tasks assigned.</p>
        ) : (
          Object.entries(taskGroups).map(([agentName, tasks], index) => {
            const validTasks = tasks.filter(
              (task) =>
                task.firstName?.trim() || task.phone?.trim() || task.notes?.trim()
            );

            if (validTasks.length === 0) return null;

            return (
              <div key={index} className="mb-8">
                <h3 className="text-xl font-semibold mb-3 text-purple-800">
                  {agentName} ({validTasks.length} task{validTasks.length > 1 ? 's' : ''})
                </h3>
                <ul className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {validTasks.map((task, i) => (
                    <li
                      key={i}
                      className="bg-gray-100 p-4 rounded-lg shadow hover:shadow-md transition-shadow duration-300"
                    >
                      <p><strong>Name:</strong> {task.firstName || 'N/A'}</p>
                      <p><strong>Phone:</strong> {task.phone || 'N/A'}</p>
                      <p><strong>Notes:</strong> {task.notes || 'N/A'}</p>
                    </li>
                  ))}
                </ul>
              </div>
            );
          })
        )}
      </div>
    </div>
  );
}
