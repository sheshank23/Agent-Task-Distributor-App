import React from 'react';
import { useNavigate } from 'react-router-dom';
import bgImage from '../assets/bg-login.webp'; // <-- Save uploaded image as bg-login.webp in /assets

export default function LoginPage() {
  const navigate = useNavigate();

  return (
    <div className="flex min-h-screen items-center justify-center bg-[#d1cedc]">
      <div className="bg-white rounded-3xl shadow-2xl flex overflow-hidden max-w-5xl w-full">
        {/* Left: Login Form */}
        <div className="w-1/2 p-10">
          <h2 className="text-3xl font-semibold mb-6 text-gray-800">✨ Welcome back</h2>
          <form>
            <div className="mb-4">
              <input
                type="email"
                placeholder="Email"
                className="w-full px-4 py-3 border rounded-lg focus:outline-none focus:ring-2 focus:ring-purple-400"
              />
            </div>
            <div className="mb-2">
              <input
                type="password"
                placeholder="Password"
                className="w-full px-4 py-3 border rounded-lg focus:outline-none focus:ring-2 focus:ring-purple-400"
              />
            </div>
            <button
              type="button"
              className="w-full py-3 bg-purple-800 hover:bg-purple-900 text-white rounded-lg transition duration-300"
              onClick={() => navigate('/dashboard')}
            >
              Sign in
            </button>
          </form>

          <p className="text-sm text-gray-500 mt-6 text-center">
         
            <span className="inline-flex gap-3 ml-2">
              <i className="fab fa-google"></i>
              <i className="fab fa-github"></i>
              <i className="fab fa-discord"></i>
            </span>
          </p>
        </div>

        {/* Right: Illustration */}
        <div className="w-1/2 relative hidden md:block">
          <img src={bgImage} alt="login art" className="h-full w-full object-cover" />
        </div>
      </div>
    </div>
  );
}
